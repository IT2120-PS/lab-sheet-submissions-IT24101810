#Exercise 01
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#Exercise 02
pexp(2, rate = 1/3)

#Exercise 03
#Part i
1 - pnorm(130, mean = 100, sd = 15)

#Part ii
qnorm(0.95, mean = 100, sd = 15)
