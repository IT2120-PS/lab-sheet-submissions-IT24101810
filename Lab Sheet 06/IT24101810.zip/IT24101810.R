#Part i
# i. What is the distribution of X?
#Binomial Distribution

# ii. What is the probability that at least 47 students passed the test?
1 - pbinom(46, 50, 0.85)


#Part ii
# i. What is the random variable (X) for the problem?
#Number of customer calls received per hour

# ii. What is the distribution of X?
#Poisson Distribution

# iii. What is the probability that exactly 15 calls are received in an hour?
dpois(15, 12)
